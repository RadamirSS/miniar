import { useAppStore } from '@/state/useAppStore'
import { CalcCard } from '@/components/CalcCard'
import { calculators } from '@/config/calculators'

import { Header } from '@/components/Header'
import { DestinyPage } from '@/features/destiny/DestinyPage'
export default function App() {
  const dob = useAppStore(s => s.dob)
  return (
    <div className="container">
      <Header />
      <DestinyPage />
      <section style={{ marginTop: 32 }}>
        <h2 style={{ fontSize: 22, marginBottom: 12 }}>Классические расчёты</h2>
        {dob ? (
          <div className="mt-4 space-y-3" style={{ marginTop: 0, display: 'grid', gap: 12 }}>
            {calculators.map(c => (
              <CalcCard key={c.id} calc={c} />
            ))}
          </div>
        ) : (
          <div className="note" style={{ marginTop: 8 }}>
            Введите дату рождения вверху экрана, чтобы увидеть расчёты.
          </div>
        )}
      </section>
    </div>
  )
}
