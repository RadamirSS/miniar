export { calculators, type CalcConfig } from '@/core/calculators'
