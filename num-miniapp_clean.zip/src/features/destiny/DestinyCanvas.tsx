import { forwardRef } from 'react'
import {
  DESTINY_EDGES,
  DESTINY_LAYOUT,
  ENERGY_FLOWS,
  type DestinyEdge,
  type EnergyFlowSpec
} from '@/lib/destiny/mapping'
import type { DestinyResult, NodeVariant } from '@/lib/destiny/types'

interface DestinyCanvasProps {
  result: DestinyResult
  className?: string
}

const VIEWBOX_SIZE = 1000

const HEART_PATH =
  'M12 21.35 10.55 20.03C5.4 15.36 2 12.27 2 8.5 2 5.41 4.42 3 7.5 3c1.74 0 3.41 0.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.41 22 8.5c0 3.77-3.4 6.86-8.55 11.54L12 21.35Z'

const DOLLAR_PATH =
  'M12 2a1 1 0 0 1 1 1v0.58c1.98.21 3.5 1.32 3.5 3.21 0 1.81-1.32 2.94-3.45 3.42l-1.05.23c-1.3.28-1.83.62-1.83 1.32 0 .81.81 1.3 2.13 1.3 1.26 0 2.32-.4 3.32-1.19a1 1 0 1 1 1.24 1.56 6.05 6.05 0 0 1-3.56 1.44V19a1 1 0 1 1-2 0v-.58c-2.19-.23-3.62-1.4-3.62-3.33 0-1.84 1.33-2.93 3.53-3.41l1.15-.26c1.26-.28 1.78-.63 1.78-1.31 0-.78-.8-1.27-2-1.27-1.1 0-2.18.32-3.07.96a1 1 0 0 1-1.17-1.62A6.1 6.1 0 0 1 11 3.58V3a1 1 0 0 1 1-1Z'

const LAYER_ORDER: Record<NonNullable<DestinyEdge['layer']>, number> = {
  grid: 0,
  guide: 1,
  accent: 2
}

const VARIANT_STYLES: Record<
  NodeVariant,
  { fill: string; stroke: string; glow?: string; text: string }
> = {
  base: {
    fill: 'rgba(251, 191, 36, 0.25)',
    stroke: 'rgba(251, 191, 36, 0.8)',
    glow: 'drop-shadow(0 18px 36px rgba(245, 158, 11, 0.35))',
    text: 'rgba(255,255,255,0.94)'
  },
  derived: {
    fill: 'rgba(139, 92, 246, 0.28)',
    stroke: 'rgba(139, 92, 246, 0.82)',
    glow: 'drop-shadow(0 14px 32px rgba(139, 92, 246, 0.35))',
    text: 'rgba(255,255,255,0.94)'
  },
  neutral: {
    fill: 'rgba(17, 17, 27, 0.88)',
    stroke: 'rgba(148, 163, 184, 0.45)',
    text: 'rgba(229, 231, 235, 0.86)'
  },
  energy: {
    fill: 'rgba(59, 130, 246, 0.18)',
    stroke: 'rgba(59, 130, 246, 0.75)',
    glow: 'drop-shadow(0 12px 24px rgba(59, 130, 246, 0.35))',
    text: 'rgba(255,255,255,0.9)'
  }
}

const BASE_FORMULA_COLORS: Record<string, { fill: string; stroke: string }> = {
  A: { fill: 'rgba(96, 165, 250, 0.25)', stroke: 'rgba(96, 165, 250, 0.85)' },
  B: { fill: 'rgba(244, 114, 182, 0.3)', stroke: 'rgba(236, 72, 153, 0.9)' },
  C: { fill: 'rgba(52, 211, 153, 0.26)', stroke: 'rgba(16, 185, 129, 0.85)' },
  D: { fill: 'rgba(251, 191, 36, 0.3)', stroke: 'rgba(251, 191, 36, 0.9)' }
}

function toSvgPoint(key: keyof typeof DESTINY_LAYOUT) {
  const [x, y] = DESTINY_LAYOUT[key]
  return [x * VIEWBOX_SIZE, y * VIEWBOX_SIZE] as const
}

function toSvgPointFromCoord(coord: readonly [number, number]) {
  return [coord[0] * VIEWBOX_SIZE, coord[1] * VIEWBOX_SIZE] as const
}

function edgePath(points: DestinyEdge['points'], close?: boolean) {
  if (!points.length) return ''
  const commands = points
    .map((key, idx) => {
      const [x, y] = toSvgPoint(key)
      return `${idx === 0 ? 'M' : 'L'} ${x.toFixed(2)} ${y.toFixed(2)}`
    })
    .join(' ')
  return close ? `${commands} Z` : commands
}

function flowPath(flow: EnergyFlowSpec) {
  const [fromX, fromY] = toSvgPoint(flow.from)
  const [toX, toY] = toSvgPoint(flow.to)
  return `M ${fromX.toFixed(2)} ${fromY.toFixed(2)} L ${toX.toFixed(2)} ${toY.toFixed(2)}`
}

function getVariantStyle(formula: string, variant: NodeVariant) {
  const overrides =
    variant === 'base' && BASE_FORMULA_COLORS[formula]
      ? BASE_FORMULA_COLORS[formula]
      : undefined
  const style = VARIANT_STYLES[variant]
  return {
    fill: overrides?.fill ?? style.fill,
    stroke: overrides?.stroke ?? style.stroke,
    glow: style.glow,
    text: style.text
  }
}

function getLabelPosition(
  radius: number,
  position: 'top' | 'bottom' | 'left' | 'right' | 'auto' = 'auto'
) {
  switch (position) {
    case 'top':
      return { x: 0, y: -radius - 22, anchor: 'middle' as const }
    case 'bottom':
      return { x: 0, y: radius + 28, anchor: 'middle' as const }
    case 'left':
      return { x: -radius - 20, y: 6, anchor: 'end' as const }
    case 'right':
      return { x: radius + 20, y: 6, anchor: 'start' as const }
    default:
      return { x: 0, y: radius + 26, anchor: 'middle' as const }
  }
}

const sortedEdges = [...DESTINY_EDGES].sort((a, b) => {
  const layerA = LAYER_ORDER[a.layer ?? 'grid'] ?? 0
  const layerB = LAYER_ORDER[b.layer ?? 'grid'] ?? 0
  return layerA - layerB
})

export const DestinyCanvas = forwardRef<SVGSVGElement, DestinyCanvasProps>(function DestinyCanvas(
  { result, className },
  ref
) {
  const nodesArray = Object.entries(result.nodes).sort(
    ([_keyA, a], [_keyB, b]) => (a.zIndex ?? 0) - (b.zIndex ?? 0)
  )

  return (
    <div className={className} style={{ position: 'relative' }}>
      <svg
        ref={ref}
        viewBox={`0 0 ${VIEWBOX_SIZE} ${VIEWBOX_SIZE}`}
        role="img"
        aria-label="Матрица судьбы"
        style={{
          width: '100%',
          height: 'auto',
          background: 'radial-gradient(circle at 50% 30%, rgba(139,92,246,.08), transparent 65%)'
        }}
      >
        <defs>
          <marker
            id="destiny-arrow"
            viewBox="0 0 12 12"
            refX="10"
            refY="6"
            markerWidth="12"
            markerHeight="12"
            orient="auto-start-reverse"
            markerUnits="strokeWidth"
          >
            <path d="M0 0 L12 6 L0 12 z" fill="context-stroke" />
          </marker>
        </defs>

        <g strokeLinecap="round" strokeLinejoin="round">
          {sortedEdges.map((edge) => {
            const d = edgePath(edge.points, edge.close)
            if (!d) return null
            return (
              <path
                key={edge.key}
                d={d}
                fill={edge.fill ?? 'none'}
                stroke={edge.color ?? 'rgba(148,163,184,0.45)'}
                strokeWidth={edge.strokeWidth ?? 2}
                strokeDasharray={edge.dasharray}
                opacity={edge.opacity ?? 1}
              />
            )
          })}
        </g>

        <g strokeLinecap="round" strokeLinejoin="round">
          {ENERGY_FLOWS.map((flow) => {
            const d = flowPath(flow)
            return (
              <path
                key={flow.key}
                d={d}
                stroke={flow.color}
                strokeWidth={flow.strokeWidth}
                fill="none"
                markerEnd="url(#destiny-arrow)"
                opacity={0.95}
              />
            )
          })}
        </g>

        <g>
          {ENERGY_FLOWS.flatMap((flow) =>
            flow.points.map((point, idx) => {
              const [x, y] = toSvgPoint(point.layout)
              const variant: NodeVariant = point.variant ?? 'energy'
              const radius = point.radius ?? 16
              const style = getVariantStyle(point.formula, variant)
              const value = result.values[point.formula] ?? 0
              const key = `${flow.key}-pt-${idx}-${point.formula}`
              return (
                <g key={key} transform={`translate(${x}, ${y})`}>
                  <circle
                    r={radius}
                    fill={style.fill}
                    stroke={style.stroke}
                    strokeWidth={2}
                    style={{ filter: style.glow }}
                    opacity={0.95}
                  />
                  <text
                    x={0}
                    y={5}
                    textAnchor="middle"
                    fontSize={radius > 18 ? 18 : 14}
                    fontWeight={600}
                    fill={style.text}
                  >
                    {value}
                  </text>
                </g>
              )
            })
          )}
        </g>

        <g>
          {nodesArray.map(([key, node]) => {
            const radius = node.radius ?? 28
            const [x, y] = toSvgPointFromCoord(node.coord)
            const style = getVariantStyle(node.formula, node.variant)
            const strokeWidth = radius >= 50 ? 5 : radius >= 36 ? 4 : 3
            const labelMeta = getLabelPosition(radius, node.labelPosition)

            return (
              <g
                key={key}
                transform={`translate(${x}, ${y})`}
                aria-label={node.label ?? node.formula}
                data-formula={node.formula}
              >
                <circle
                  r={radius}
                  fill={style.fill}
                  stroke={style.stroke}
                  strokeWidth={strokeWidth}
                  style={{ filter: style.glow }}
                />
                <text
                  x={0}
                  y={6}
                  textAnchor="middle"
                  fontSize={radius > 70 ? 44 : radius > 50 ? 34 : radius > 30 ? 28 : 22}
                  fontWeight={700}
                  fill={style.text}
                >
                  {node.value}
                </text>
                {node.icon ? (
                  <g transform={`translate(${radius - 22}, ${-radius + 22})`}>
                    <rect
                      x={-18}
                      y={-18}
                      width={36}
                      height={36}
                      rx={12}
                      fill={
                        node.icon === 'heart'
                          ? 'rgba(236, 72, 153, 0.28)'
                          : 'rgba(74, 222, 128, 0.28)'
                      }
                      stroke="rgba(255,255,255,0.25)"
                    />
                    <path
                      d={node.icon === 'heart' ? HEART_PATH : DOLLAR_PATH}
                      fill="rgba(255,255,255,0.92)"
                      transform="scale(0.65) translate(-16 -12)"
                    />
                  </g>
                ) : null}
                {node.label ? (
                  <text
                    x={labelMeta.x}
                    y={labelMeta.y}
                    textAnchor={labelMeta.anchor}
                    fontSize={radius > 46 ? 22 : 18}
                    fill="rgba(255,255,255,0.82)"
                    style={{ letterSpacing: 0.2 }}
                  >
                    {node.label}
                  </text>
                ) : null}
              </g>
            )
          })}
        </g>
      </svg>
    </div>
  )
})

